package com.ibizungu.ibizungu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
