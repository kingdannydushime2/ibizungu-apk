import 'card_model.dart';
import 'player_model.dart';

/// Mode de jeu
enum GameMode {
  individual, // Mode Individuel
  groups,    // Mode Groupes
}

/// État du jeu
enum GameStatus {
  waiting,    // En attente de joueurs
  bet,        // Phase de mise
  dealing,    // Distribution des cartes
  playing,    // En cours
  finished,   // Terminé
  cancelled,  // Annulé
}

/// Modèle d'état du jeu
class GameState {
  final String roomCode;
  final GameMode mode;
  final GameStatus status;
  final List<Player> players;
  final List<PlayingCard> deck;
  final Map<String, List<PlayingCard>> playerCards;
  final CardSuit? strongSuit; // Couleur forte (iyatotse)
  final int currentPlayerIndex;
  final int currentBet;
  final int potAmount;
  final List<PlayingCard> tableCards;
  final int trickNumber;
  final String? winnerId;
  final String? message;
  final DateTime createdAt;

  GameState({
    required this.roomCode,
    this.mode = GameMode.individual,
    this.status = GameStatus.waiting,
    required this.players,
    required this.deck,
    this.playerCards = const {},
    this.strongSuit,
    this.currentPlayerIndex = 0,
    this.currentBet = 50,
    this.potAmount = 0,
    this.tableCards = const [],
    this.trickNumber = 0,
    this.winnerId,
    this.message,
    required this.createdAt,
  });

  Player? get currentPlayer {
    if (players.isEmpty || currentPlayerIndex >= players.length) return null;
    return players[currentPlayerIndex];
  }

  /// Retourne toutes les cartes en jeu (deck complet)
  List<PlayingCard> get allCards => deck;

  /// Retourne toutes les cartes distribuées aux joueurs
  List<PlayingCard> get distributedCards {
    final cards = <PlayingCard>[];
    for (var cardList in playerCards.values) {
      cards.addAll(cardList);
    }
    return cards;
  }

  GameState copyWith({
    String? roomCode,
    GameMode? mode,
    GameStatus? status,
    List<Player>? players,
    List<PlayingCard>? deck,
    Map<String, List<PlayingCard>>? playerCards,
    CardSuit? strongSuit,
    int? currentPlayerIndex,
    int? currentBet,
    int? potAmount,
    List<PlayingCard>? tableCards,
    int? trickNumber,
    String? winnerId,
    bool clearWinnerId = false,  // Pour explicitly set winnerId to null
    String? message,
    DateTime? createdAt,
  }) {
    return GameState(
      roomCode: roomCode ?? this.roomCode,
      mode: mode ?? this.mode,
      status: status ?? this.status,
      players: players ?? this.players,
      deck: deck ?? this.deck,
      playerCards: playerCards ?? this.playerCards,
      strongSuit: strongSuit ?? this.strongSuit,
      currentPlayerIndex: currentPlayerIndex ?? this.currentPlayerIndex,
      currentBet: currentBet ?? this.currentBet,
      potAmount: potAmount ?? this.potAmount,
      tableCards: tableCards ?? this.tableCards,
      trickNumber: trickNumber ?? this.trickNumber,
      winnerId: clearWinnerId ? null : (winnerId ?? this.winnerId),
      message: message ?? this.message,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
    'roomCode': roomCode,
    'mode': mode.index,
    'status': status.index,
    'players': players.map((p) => p.toJson()).toList(),
    'deck': deck.map((c) => c.toJson()).toList(),
    'playerCards': playerCards.map(
      (key, value) => MapEntry(key, value.map((c) => c.toJson()).toList()),
    ),
    'strongSuit': strongSuit?.index,
    'currentPlayerIndex': currentPlayerIndex,
    'currentBet': currentBet,
    'potAmount': potAmount,
    'tableCards': tableCards.map((c) => c.toJson()).toList(),
    'trickNumber': trickNumber,
    'winnerId': winnerId,
    'message': message,
    'createdAt': createdAt.toIso8601String(),
  };

  factory GameState.fromJson(Map<String, dynamic> json) {
    return GameState(
      roomCode: json['roomCode'] as String,
      mode: GameMode.values[json['mode'] as int],
      status: GameStatus.values[json['status'] as int],
      players: (json['players'] as List)
          .map((p) => Player.fromJson(p as Map<String, dynamic>))
          .toList(),
      deck: (json['deck'] as List)
          .map((c) => PlayingCard.fromJson(c as Map<String, dynamic>))
          .toList(),
      playerCards: (json['playerCards'] as Map<String, dynamic>).map(
        (key, value) => MapEntry(
          key,
          (value as List)
              .map((c) => PlayingCard.fromJson(c as Map<String, dynamic>))
              .toList(),
        ),
      ),
      strongSuit: json['strongSuit'] != null
          ? CardSuit.values[json['strongSuit'] as int]
          : null,
      currentPlayerIndex: json['currentPlayerIndex'] as int,
      currentBet: json['currentBet'] as int,
      potAmount: json['potAmount'] as int,
      tableCards: (json['tableCards'] as List)
          .map((c) => PlayingCard.fromJson(c as Map<String, dynamic>))
          .toList(),
      trickNumber: json['trickNumber'] as int,
      winnerId: json['winnerId'] as String?,
      message: json['message'] as String?,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }
}
