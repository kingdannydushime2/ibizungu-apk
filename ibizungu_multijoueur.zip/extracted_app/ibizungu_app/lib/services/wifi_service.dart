import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/models.dart';
import 'multiplayer/multiplayer.dart';

/// Service Wi-Fi pour le multijoueur local
/// Gère la communication entre joueurs sur le même réseau via sockets
class WiFiService extends ChangeNotifier {
  IbizunguSocketServer? _server;
  IbizunguSocketClient? _client;
  String? _roomCode;
  bool _isHost = false;
  Player? _currentPlayer;
  GameState? _remoteGameState;
  List<Player> _connectedPlayers = [];

  // Callback pour broadcaster l'état du jeu depuis le GameService
  Function(GameState)? _gameStateCallback;

  // Callback pour les actions de jeu (hôte uniquement)
  Function(String playerId, String actionType, Map<String, dynamic>? actionData)? _gameActionCallback;

  final List<Function(GameState)> _gameStateListeners = [];
  final List<Function(Player)> _playerJoinedListeners = [];
  final List<Function(String)> _playerLeftListeners = [];

  bool get isHost => _isHost;
  String? get roomCode => _roomCode;
  List<Player> get connectedPlayers => _connectedPlayers;
  GameState? get remoteGameState => _remoteGameState;
  Player? get currentPlayer => _currentPlayer;

  /// Définit le callback pour broadcaster l'état du jeu
  void setBroadcastCallback(Function(GameState)? callback) {
    _gameStateCallback = callback;
  }

  /// Définit le callback pour les actions de jeu (hôte uniquement)
  void setGameActionCallback(Function(String playerId, String actionType, Map<String, dynamic>? actionData)? callback) {
    _gameActionCallback = callback;
  }

  /// Méthode interne pour broadcaster l'état (appelée par GameService)
  void _broadcastGameStateFromService(GameState state) {
    if (_gameStateCallback != null) {
      _gameStateCallback!(state);
    }
  }

  /// Initialise le service avec le joueur courant
  void init(Player player) {
    _currentPlayer = player;
    _connectedPlayers = [player];
  }

  /// Crée une salle en tant qu'hôte
  Future<bool> createRoom(String roomCode, Player host) async {
    try {
      _roomCode = roomCode;
      _isHost = true;
      _currentPlayer = host;
      _connectedPlayers = [host];

      // Crée et démarre le serveur
      _server = IbizunguSocketServer();

      // Configure les callbacks du serveur
      _setupServerCallbacks();

      // Démarre le serveur
      final success = await _server!.start();

      if (success) {
        // Configure la room avec l'hôte comme participant
        final hostParticipant = GameParticipant(
          id: host.id,
          pseudo: host.pseudo,
          isHost: true,
          isReady: true,
          ddkBalance: host.ddkBalance,
          teamId: host.teamId,
        );

        _server!.setRoom(roomCode, [hostParticipant]);
        notifyListeners();
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('Erreur création salle: $e');
      return false;
    }
  }

  /// Configure les callbacks du serveur
  void _setupServerCallbacks() {
    _server?.onParticipantJoined = (participant) {
      debugPrint('Participant rejoint: ${(participant as GameParticipant).pseudo}');

      // Crée un Player à partir du GameParticipant
      final player = Player(
        id: participant.id,
        pseudo: participant.pseudo,
        ddkBalance: participant.ddkBalance,
        isHost: participant.isHost,
        teamId: participant.teamId,
        isReady: participant.isReady,
      );

      _notifyPlayerJoined(player);
    };

    _server?.onParticipantLeft = (participantId) {
      debugPrint('Participant parti: $participantId');
      _notifyPlayerLeft(participantId as String);
    };

    _server?.onParticipantsUpdated = (participants) {
      debugPrint('Participants mis à jour');
      // Met à jour la liste locale des joueurs
      _connectedPlayers = _connectedPlayers.map((p) {
        final updated = participants.firstWhere(
          (gp) => gp.id == p.id,
          orElse: () => GameParticipant(id: p.id, pseudo: p.pseudo),
        );
        return Player(
          id: updated.id,
          pseudo: updated.pseudo,
          ddkBalance: updated.ddkBalance,
          isHost: updated.isHost,
          teamId: updated.teamId,
          isReady: updated.isReady,
        );
      }).toList();
      notifyListeners();
    };

    _server?.onGameAction = (data) {
      debugPrint('Action de jeu reçue: $data');
      // Transmet l'action au GameService via le callback
      if (data != null && _gameActionCallback != null) {
        final actionData = data as Map<String, dynamic>?;
        if (actionData != null) {
          final participantId = actionData['participantId'] as String? ?? '';
          final actionType = actionData['actionType'] as String? ?? '';
          final actionPayload = actionData['actionData'] as Map<String, dynamic>?;
          _gameActionCallback!(participantId, actionType, actionPayload);
        }
      }
    };

    // Callback pour demander l'état du jeu
    _server?.onGameStateRequested = (clientSocket) {
      debugPrint('État du jeu demandé par un client');
      // Récupère l'état actuel du GameService et l'envoie au client
      // Note: onGameStateCallback contient l'état à envoyer
      // Cette fonctionnalité sera utilisée quand le client joined
    };
  }

  /// Rejoint une salle en tant que client
  Future<bool> joinRoom(String hostAddress, int port, String roomCode, Player player) async {
    try {
      _roomCode = roomCode;
      _isHost = false;
      _currentPlayer = player;
      _connectedPlayers = [player];

      // Crée le client
      _client = IbizunguSocketClient();

      // Configure les callbacks du client
      _setupClientCallbacks();

      // Connecte au serveur
      final participant = GameParticipant(
        id: player.id,
        pseudo: player.pseudo,
        isHost: false,
        isReady: false,
        ddkBalance: player.ddkBalance,
        teamId: player.teamId,
      );

      final success = await _client!.connect(hostAddress, port, roomCode, participant);

      if (success) {
        notifyListeners();
        return true;
      }

      return false;
    } catch (e) {
      debugPrint('Erreur rejoindre salle: $e');
      return false;
    }
  }

  /// Configure les callbacks du client
  void _setupClientCallbacks() {
    _client?.onJoined = (participant) {
      debugPrint('Connecté à la room');
      _currentPlayer = Player(
        id: participant.id,
        pseudo: participant.pseudo,
        ddkBalance: participant.ddkBalance,
        isHost: participant.isHost,
        teamId: participant.teamId,
      );
      _connectedPlayers = [Player(
        id: participant.id,
        pseudo: participant.pseudo,
        ddkBalance: participant.ddkBalance,
        isHost: participant.isHost,
        teamId: participant.teamId,
      )];
      notifyListeners();
    };

    _client?.onParticipantsUpdated = (participants) {
      debugPrint('Participants mis à jour');
      // Met à jour la liste locale des joueurs
      _connectedPlayers = participants.map((gp) => Player(
        id: gp.id,
        pseudo: gp.pseudo,
        ddkBalance: gp.ddkBalance,
        isHost: gp.isHost,
        teamId: gp.teamId,
        isReady: gp.isReady,
      )).toList();
      notifyListeners();
    };

    _client?.onParticipantJoined = (participantId) {
      debugPrint('Nouveau participant: $participantId');
      // Le participant sera ajouté via onParticipantsUpdated
      notifyListeners();
    };

    _client?.onParticipantLeft = (participantId) {
      debugPrint('Participant parti: $participantId');
      _connectedPlayers.removeWhere((p) => p.id == participantId);
      _notifyPlayerLeft(participantId);
      notifyListeners();
    };

    _client?.onGameStateReceived = (gameState) {
      debugPrint('État du jeu reçu');
      _remoteGameState = GameState.fromJson(gameState);
      _notifyGameStateListeners();
      notifyListeners();
    };

    _client?.onGameStart = (initialState) {
      debugPrint('Jeu démarré');
      if (initialState.isNotEmpty) {
        _remoteGameState = GameState.fromJson(initialState);
        _notifyGameStateListeners();
      }
      notifyListeners();
    };

    _client?.onGameOver = (winnerId, message, potAmount, finalState) {
      debugPrint('Jeu terminé: $winnerId - $message');
      if (finalState != null) {
        _remoteGameState = GameState.fromJson(finalState);
        _notifyGameStateListeners();
      }
      notifyListeners();
    };

    _client?.onRoomClosed = () {
      debugPrint('Room fermée par l\'hôte');
      _notifyPlayerLeft('room_closed');
      notifyListeners();
    };

    _client?.onDisconnected = () {
      debugPrint('Déconnecté du serveur');
      notifyListeners();
    };

    _client?.onError = (error) {
      debugPrint('Erreur: $error');
      notifyListeners();
    };
  }

  /// Diffuse l'état du jeu à tous les clients (hôte uniquement)
  void broadcastGameState(GameState state) {
    if (_isHost && _server != null) {
      // Met à jour l'état du jeu sur le serveur pour les nouveaux clients
      _server!.setGameState(state.toJson());
      _server!.broadcastGameState(state.toJson());
    }
  }

  /// Diffuse le démarrage du jeu (hôte uniquement)
  void broadcastGameStart(GameState state) {
    if (_isHost && _server != null) {
      _server!.broadcastGameStart(state.toJson());
    }
  }

  /// Diffuse la fin du jeu (hôte uniquement)
  void broadcastGameOver(GameState state) {
    if (_isHost && _server != null) {
      _server!.broadcastGameOver(
        state.winnerId ?? '',
        state.message ?? 'Partie terminée',
        state.potAmount,
        state.toJson(),
      );
    }
  }

  /// Diffuse que la room est prête (hôte uniquement)
  void broadcastRoomReady(bool isReady) {
    if (_isHost && _server != null) {
      _server!.broadcastRoomReady(isReady);
    }
  }

  /// Demande l'état actuel du jeu (client uniquement)
  void requestGameState() {
    if (!_isHost && _client != null) {
      _client!.requestGameState();
    }
  }

  /// Envoie une action de jeu (client uniquement)
  void sendGameAction(String actionType, Map<String, dynamic>? actionData) {
    if (!_isHost && _client != null) {
      _client!.sendGameAction(actionType, actionData);
    }
  }

  /// Obtient l'adresse IP locale
  Future<String?> getLocalIpAddress() async {
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
      );

      for (var interface in interfaces) {
        for (var addr in interface.addresses) {
          if (!addr.isLoopback) {
            return addr.address;
          }
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Génère les données QR pour l'hôte
  Future<String> generateHostQrData() async {
    final localIp = await getLocalIpAddress() ?? '127.0.0.1';
    return 'IBZUNG:HOST:$localIp:8080:$_roomCode';
  }

  /// Génère les données QR pour le joueur
  Future<String> generatePlayerQrData() async {
    final localIp = await getLocalIpAddress() ?? '127.0.0.1';
    return 'IBZUNG:PLAYER:$localIp:8080:$_roomCode';
  }

  /// Parse les données QR pour rejoindre une partie
  static Map<String, dynamic>? parseQrData(String data) {
    try {
      final parts = data.split(':');
      if (parts.length < 5) return null;

      final prefix = parts[0];
      final type = parts[1];
      final ip = parts[2];
      final port = parts[3];
      final roomCode = parts[4];

      if (prefix != 'IBZUNG') return null;
      if (type != 'HOST' && type != 'PLAYER') return null;

      final ipRegex = RegExp(r'^(\d{1,3}\.){3}\d{1,3}$');
      if (!ipRegex.hasMatch(ip)) return null;

      final portNum = int.tryParse(port);
      if (portNum == null || portNum < 1 || portNum > 65535) return null;

      final roomCodeRegex = RegExp(r'^\d{6}$');
      if (!roomCodeRegex.hasMatch(roomCode)) return null;

      return {
        'hostIp': ip,
        'port': portNum,
        'roomCode': roomCode,
        'type': type,
      };
    } catch (e) {
      debugPrint('Erreur parsing QR: $e');
      return null;
    }
  }

  /// Valide les données de connexion
  static bool validateConnectionData(String? ip, String? port, String? roomCode) {
    if (ip == null || ip.isEmpty) return false;
    if (port == null || port.isEmpty) return false;
    if (roomCode == null || roomCode.isEmpty) return false;

    final ipRegex = RegExp(r'^(\d{1,3}\.){3}\d{1,3}$');
    if (!ipRegex.hasMatch(ip)) return false;

    final portNum = int.tryParse(port);
    if (portNum == null || portNum < 1 || portNum > 65535) return false;

    final roomCodeRegex = RegExp(r'^\d{6}$');
    if (!roomCodeRegex.hasMatch(roomCode)) return false;

    return true;
  }

  /// Génère un code de salle
  static String generateRoomCode() {
    final random = DateTime.now().millisecondsSinceEpoch % 900000;
    return (random + 100000).toString();
  }

  // ============ Listeners ============

  /// Ajoute un listener pour l'état du jeu
  void addGameStateListener(Function(GameState) listener) {
    _gameStateListeners.add(listener);
  }

  void removeGameStateListener(Function(GameState) listener) {
    _gameStateListeners.remove(listener);
  }

  void _notifyGameStateListeners() {
    if (_remoteGameState != null) {
      for (var listener in _gameStateListeners) {
        listener(_remoteGameState!);
      }
      notifyListeners();
    }
  }

  /// Ajoute un listener pour les connexions
  void addPlayerJoinedListener(Function(Player) listener) {
    _playerJoinedListeners.add(listener);
  }

  void removePlayerJoinedListener(Function(Player) listener) {
    _playerJoinedListeners.remove(listener);
  }

  void _notifyPlayerJoined(Player player) {
    if (!_connectedPlayers.any((p) => p.id == player.id)) {
      _connectedPlayers.add(player);
    }
    for (var listener in _playerJoinedListeners) {
      listener(player);
    }
    notifyListeners();
  }

  /// Ajoute un listener pour les déconnections
  void addPlayerLeftListener(Function(String) listener) {
    _playerLeftListeners.add(listener);
  }

  void removePlayerLeftListener(Function(String) listener) {
    _playerLeftListeners.remove(listener);
  }

  void _notifyPlayerLeft(String playerId) {
    _connectedPlayers.removeWhere((p) => p.id == playerId);
    for (var listener in _playerLeftListeners) {
      listener(playerId);
    }
    notifyListeners();
  }

  /// Quitte la salle
  Future<void> leaveRoom() async {
    if (_isHost) {
      // Hôte: ferme le serveur
      if (_server != null) {
        _server!.closeRoom('L\'hôte a quitté');
        await _server!.dispose();
        _server = null;
      }
    } else {
      // Client: se déconnecte
      if (_client != null) {
        await _client!.dispose();
        _client = null;
      }
    }

    _roomCode = null;
    _isHost = false;
    _currentPlayer = null;
    _remoteGameState = null;
    _connectedPlayers.clear();

    notifyListeners();
  }

  @override
  void dispose() {
    leaveRoom();
    super.dispose();
  }
}
