import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// Service OCR pour la vérification des transactions Lumicash
class OcrService {
  final TextRecognizer _textRecognizer = TextRecognizer();

  /// Vérifie si une image contient le message de confirmation Lumitel
  /// Retourne un tuple (bool isValid, String? message)
  Future<(bool, String?)> verifyLumitelTransaction(
    File imageFile,
    int expectedAmount,
  ) async {
    try {
      final inputImage = InputImage.fromFile(imageFile);
      final recognizedText = await _textRecognizer.processImage(inputImage);
      
      final fullText = recognizedText.text.toLowerCase();
      
      // Message attendu dans le SMS LUMITEL
      // Format: "Message de LUMITEL : votre transaction de {montant}FBU a réussi"
      final expectedPatterns = [
        'lumitel',
        'transaction',
        'a réussi',
        '${expectedAmount}fbu',
      ];
      
      // Vérifie que tous les éléments sont présents
      bool hasLumitel = fullText.contains('lumitel');
      bool hasTransaction = fullText.contains('transaction');
      bool hasSuccess = fullText.contains('a réussi') || fullText.contains('reussi');
      bool hasAmount = fullText.contains('${expectedAmount}fbu') || 
                       fullText.contains('${expectedAmount} fbu') ||
                       fullText.contains('${expectedAmount}fb');
      
      if (hasLumitel && hasTransaction && hasSuccess && hasAmount) {
        return (true, 'Transaction vérifiée avec succès! SMS LUMITEL détecté.');
      }
      
      // Analyse des erreurs
      List<String> missing = [];
      if (!hasLumitel) missing.add('lumitel');
      if (!hasTransaction) missing.add('transaction');
      if (!hasSuccess) missing.add('confirmation de succès');
      if (!hasAmount) missing.add('montant $expectedAmount FBU');
      
      return (false, 'Message incomplet. Éléments manquants: ${missing.join(", ")}');
      
    } catch (e) {
      debugPrint('Erreur OCR: $e');
      return (false, 'Erreur lors de l\'analyse de l\'image. Veuillez réessayer avec une capture plus claire.');
    }
  }

  /// Nettoie les ressources
  void dispose() {
    _textRecognizer.close();
  }
}
