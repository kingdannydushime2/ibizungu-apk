import 'package:flutter/material.dart';
import '../models/models.dart';
import '../utils/theme.dart';

/// Widget d'affichage d'une carte de jeu réaliste
class CardWidget extends StatelessWidget {
  final PlayingCard? card;
  final bool isFaceDown;
  final bool isSelected;
  final double size;
  final VoidCallback? onTap;

  const CardWidget({
    super.key,
    this.card,
    this.isFaceDown = false,
    this.isSelected = false,
    this.size = 80,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: size,
        height: size * 1.4,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size * 0.1),
          boxShadow: [
            // Ombre principale
            BoxShadow(
              color: isSelected
                  ? AppTheme.primaryGold.withValues(alpha: 0.6)
                  : Colors.black.withValues(alpha: 0.4),
              blurRadius: isSelected ? 16 : 8,
              offset: Offset(0, isSelected ? 6 : 4),
              spreadRadius: isSelected ? 2 : 0,
            ),
            // Reflet subtil
            BoxShadow(
              color: Colors.white.withValues(alpha: 0.1),
              blurRadius: 2,
              offset: const Offset(0, -1),
            ),
          ],
          transform: isSelected
              ? (Matrix4.identity()..translate(0.0, -12.0))
              : Matrix4.identity(),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(size * 0.1),
          child: isFaceDown ? _buildCardBack() : _buildCardFront(),
        ),
      ),
    );
  }

  Widget _buildCardBack() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF1E3A5F),
            const Color(0xFF0D1F33),
          ],
        ),
      ),
      child: Stack(
        children: [
          // Motif de dos de carte - losanges
          CustomPaint(
            size: Size(size, size * 1.4),
            painter: _CardBackPatternPainter(),
          ),
          // Bordure dorée
          Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: AppTheme.primaryGold.withValues(alpha: 0.6),
                width: 2,
              ),
              borderRadius: BorderRadius.circular(size * 0.1),
            ),
          ),
          // Centre avec logo
          Center(
            child: Container(
              width: size * 0.5,
              height: size * 0.5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppTheme.primaryGold.withValues(alpha: 0.4),
                  width: 2,
                ),
              ),
              child: const Center(
                child: Text(
                  'IBZ',
                  style: TextStyle(
                    color: AppTheme.primaryGold,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCardFront() {
    if (card == null) {
      return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.feltGreen,
              AppTheme.pokerGreen,
            ],
          ),
          borderRadius: BorderRadius.circular(size * 0.1),
        ),
      );
    }

    final isRed = card!.suit == CardSuit.hearts || card!.suit == CardSuit.diamonds;
    final textColor = isRed ? AppTheme.cardRed : AppTheme.cardBlack;

    return Container(
      decoration: BoxDecoration(
        // Fond blanc avec texture subtile
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white,
            Colors.grey.shade100,
            Colors.white,
          ],
        ),
        borderRadius: BorderRadius.circular(size * 0.1),
        // Bordure subtile
        border: Border.all(
          color: isRed
              ? AppTheme.cardRed.withValues(alpha: 0.2)
              : Colors.grey.shade300,
          width: 1,
        ),
      ),
      child: Stack(
        children: [
          // Texture papier subtile
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(size * 0.09),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withValues(alpha: 0.5),
                    Colors.transparent,
                    Colors.grey.withValues(alpha: 0.03),
                  ],
                ),
              ),
            ),
          ),
          
          // Coin supérieur gauche
          Positioned(
            top: size * 0.05,
            left: size * 0.05,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  card!.rankName,
                  style: TextStyle(
                    color: textColor,
                    fontSize: size * 0.16,
                    fontWeight: FontWeight.bold,
                    height: 1,
                    shadows: [
                      Shadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 1,
                        offset: const Offset(1, 1),
                      ),
                    ],
                  ),
                ),
                Text(
                  card!.suitSymbol,
                  style: TextStyle(
                    color: textColor,
                    fontSize: size * 0.2,
                    height: 1,
                    shadows: [
                      Shadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 1,
                        offset: const Offset(1, 1),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Centre - grand symbole
          Center(
            child: Text(
              card!.suitSymbol,
              style: TextStyle(
                color: textColor,
                fontSize: size * 0.5,
                shadows: [
                  Shadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 2,
                    offset: const Offset(2, 2),
                  ),
                ],
              ),
            ),
          ),
          
          // Indicateur ibimari (As ou 7)
          if (card!.isIbimari)
            Positioned(
              top: size * 0.05,
              right: size * 0.05,
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  color: AppTheme.primaryGold.withValues(alpha: 0.3),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.star,
                  size: size * 0.08,
                  color: AppTheme.primaryGold,
                ),
              ),
            ),
          
          // Coin inférieur droit (inversé)
          Positioned(
            bottom: size * 0.05,
            right: size * 0.05,
            child: Transform.rotate(
              angle: 3.14159,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    card!.rankName,
                    style: TextStyle(
                      color: textColor,
                      fontSize: size * 0.16,
                      fontWeight: FontWeight.bold,
                      height: 1,
                      shadows: [
                        Shadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 1,
                          offset: const Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    card!.suitSymbol,
                    style: TextStyle(
                      color: textColor,
                      fontSize: size * 0.2,
                      height: 1,
                      shadows: [
                        Shadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 1,
                          offset: const Offset(1, 1),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Effet de brillance subtil
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: size * 0.3,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(size * 0.1),
                  topRight: Radius.circular(size * 0.1),
                ),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withValues(alpha: 0.3),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Peintre personnalisé pour le motif du dos de carte
class _CardBackPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.primaryGold.withValues(alpha: 0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    // Dessine des losanges
    final spacing = size.width * 0.15;
    final rows = (size.height / spacing).ceil();
    final cols = (size.width / spacing).ceil();

    for (int row = 0; row < rows; row++) {
      for (int col = 0; col < cols; col++) {
        final x = col * spacing + (row.isOdd ? spacing / 2 : 0);
        final y = row * spacing;

        if (x >= 0 && x < size.width && y >= 0 && y < size.height) {
          final path = Path()
            ..moveTo(x, y - spacing / 4)
            ..lineTo(x + spacing / 4, y)
            ..lineTo(x, y + spacing / 4)
            ..lineTo(x - spacing / 4, y)
            ..close();

          canvas.drawPath(path, paint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
