import 'package:flutter/material.dart';
import '../models/models.dart';
import '../utils/theme.dart';

/// Widget d'avatar de joueur
class PlayerAvatar extends StatelessWidget {
  final Player player;
  final bool isCurrentTurn;
  final bool showDdk;
  final double size;
  final bool isAdminView;
  final Color? teamColor;

  const PlayerAvatar({
    super.key,
    required this.player,
    this.isCurrentTurn = false,
    this.showDdk = true,
    this.size = 60,
    this.isAdminView = false,
    this.teamColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          children: [
            // Avatar
            Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isAdminView
                    ? Colors.purple.withValues(alpha: 0.3)
                    : AppTheme.surfaceDark,
                border: Border.all(
                  color: isCurrentTurn
                      ? AppTheme.primaryGold
                      : (isAdminView ? Colors.purple : (teamColor ?? Colors.transparent)),
                  width: 3,
                ),
                boxShadow: isCurrentTurn
                    ? [
                        BoxShadow(
                          color: AppTheme.primaryGold.withValues(alpha: 0.4),
                          blurRadius: 12,
                          spreadRadius: 2,
                        ),
                      ]
                    : null,
              ),
              child: Center(
                child: isAdminView
                    ? const Icon(Icons.visibility, color: Colors.purple, size: 24)
                    : Text(
                        player.pseudo.isNotEmpty
                            ? player.pseudo[0].toUpperCase()
                            : '?',
                        style: TextStyle(
                          color: AppTheme.primaryGold,
                          fontSize: size * 0.4,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
            // Indicateur de tour
            if (isCurrentTurn)
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  width: size * 0.3,
                  height: size * 0.3,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.primaryGold,
                  ),
                  child: const Icon(
                    Icons.play_arrow,
                    color: Colors.black,
                    size: 16,
                  ),
                ),
              ),
            // Indicateur de connexion
            if (!player.isConnected)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withValues(alpha: 0.5),
                  ),
                  child: const Icon(
                    Icons.wifi_off,
                    color: Colors.red,
                    size: 24,
                  ),
                ),
              ),
            // Badge hôte
            if (player.isHost && !isAdminView)
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.primaryGold,
                  ),
                  child: const Icon(
                    Icons.star,
                    color: Colors.black,
                    size: 12,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        // Pseudo
        SizedBox(
          width: size + 20,
          child: Text(
            player.pseudo,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: isCurrentTurn ? AppTheme.primaryGold : Colors.white,
              fontSize: 12,
              fontWeight: isCurrentTurn ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
        // Solde DDK
        if (showDdk && !isAdminView)
          Text(
            '${player.ddkBalance} DDK',
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 10,
            ),
          ),
      ],
    );
  }
}
