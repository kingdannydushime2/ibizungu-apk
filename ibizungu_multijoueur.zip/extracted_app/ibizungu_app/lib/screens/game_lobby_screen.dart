import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../services/services.dart';
import '../utils/theme.dart';
import '../widgets/widgets.dart';

/// Écran de lobby de jeu
class GameLobbyScreen extends StatefulWidget {
  const GameLobbyScreen({super.key});

  @override
  State<GameLobbyScreen> createState() => _GameLobbyScreenState();
}

class _GameLobbyScreenState extends State<GameLobbyScreen> {
  final _roomCodeController = TextEditingController();
  final _ipController = TextEditingController();
  WiFiService? _wifiService;
  GameService? _gameService;
  bool _isHost = false;
  GameMode _gameMode = GameMode.individual;
  int _playerCount = 4;
  String? _roomCode;
  String? _localIp;
  List<Player> _players = [];
  bool _isLoading = false;
  double _betAmount = 50.0;
  static const double _minBet = 50.0;
  static const double _maxBet = 500.0;

  @override
  void initState() {
    super.initState();
    _loadLocalIp();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Obtenir les services du Provider pour partager l'état entre joueurs
    _wifiService = context.read<WiFiService>();
    _gameService = context.read<GameService>();

    _wifiService!.addPlayerJoinedListener(_onPlayerJoined);
    _wifiService!.addPlayerLeftListener(_onPlayerLeft);
    _wifiService!.addGameStateListener(_onRemoteGameState);

    // Écouter les changements d'état du GameService
    _gameService!.addStateListener(_onLocalGameStateChanged);

    // Configure les callbacks pour le WiFiService
    _setupNetworkCallbacks();

    // Gère les arguments de route
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null) {
      _isHost = args['isHost'] ?? false;
      if (args['mode'] == 'groups') {
        _gameMode = GameMode.groups;
      }
    }
  }

  void _setupNetworkCallbacks() {
    // Configure le callback pour les actions de jeu des clients (hôte uniquement)
    if (_wifiService != null && _gameService != null) {
      // Définir le callback de game action sur le WiFiService
      // pour transmettre les actions au GameService
      _wifiService!.setGameActionCallback((playerId, actionType, actionData) {
        debugPrint('Action reçue de $_playerId: $actionType');
        _gameService!.processGameActionFromNetwork(playerId, actionType, actionData);
      });
    }
  }

  void _onRemoteGameState(GameState state) {
    // Synchroniser l'état du jeu reçu depuis l'hôte
    if (mounted) {
      setState(() {
        _players = List.from(state.players);
      });
    }
  }

  void _onLocalGameStateChanged(GameState state) {
    // Mettre à jour la liste des joueurs depuis le GameService local
    if (mounted) {
      setState(() {
        _players = List.from(state.players);
      });
    }
  }

  Future<void> _loadLocalIp() async {
    // Obtenir l'IP via le service temporaire ou directement
    try {
      final tempWifi = WiFiService();
      final ip = await tempWifi.getLocalIpAddress();
      if (mounted) {
        setState(() => _localIp = ip ?? '127.0.0.1');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _localIp = '127.0.0.1');
      }
    }
  }

  @override
  void dispose() {
    // Supprimer les listeners seulement si les services sont initialisés
    _wifiService?.removePlayerJoinedListener(_onPlayerJoined);
    _wifiService?.removePlayerLeftListener(_onPlayerLeft);
    _wifiService?.removeGameStateListener(_onRemoteGameState);
    _gameService?.removeStateListener(_onLocalGameStateChanged);
    _wifiService?.leaveRoom();
    _roomCodeController.dispose();
    _ipController.dispose();
    super.dispose();
  }

  void _onPlayerJoined(Player player) {
    setState(() {
      if (!_players.any((p) => p.id == player.id)) {
        _players.add(player);
      }
    });
    // Ajouter aussi au GameService si disponible
    _gameService?.addPlayer(player);
  }

  void _onPlayerLeft(String playerId) {
    setState(() {
      _players.removeWhere((p) => p.id == playerId);
    });
    // Retirer aussi du GameService si disponible
    _gameService?.removePlayer(playerId);
  }

  Future<void> _createRoom() async {
    if (_wifiService == null || _gameService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur: Services non initialisés')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final storageService = context.read<StorageService>();
      final pseudo = storageService.getPseudo() ?? 'Hôte';
      final playerId = storageService.getPlayerId() ?? const Uuid().v4();

      _roomCode = WiFiService.generateRoomCode();

      final host = Player(
        id: playerId,
        pseudo: pseudo,
        ddkBalance: storageService.getDdkBalance(),
        isHost: true,
      );

      final success = await _wifiService!.createRoom(_roomCode!, host);

      if (success) {
        // Met à jour l'état local
        _isHost = true;

        // Initialise le WiFiService avec l'hôte
        _wifiService!.init(host);

        // Attend un peu pour que le serveur soit prêt
        await Future.delayed(const Duration(milliseconds: 500));

        await _loadLocalIp();

        setState(() {
          _players = [host];
        });

        // Définir le callback de broadcast pour synchroniser l'état du jeu
        _wifiService!.setBroadcastCallback((state) {
          _wifiService!.broadcastGameState(state);
        });

        _gameService!.createGame(
          roomCode: _roomCode!,
          host: host,
          mode: _gameMode,
          initialBet: _betAmount.round(),
        );

        // Configurer le callback de broadcast pour le GameService
        _gameService!.setBroadcastCallback((state) {
          _wifiService!.broadcastGameState(state);
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Erreur lors de la création de la salle')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _joinRoomWithData(String hostIp, int port, String roomCode) async {
    if (_wifiService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur: Service WiFi non initialisé')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final storageService = context.read<StorageService>();
      final pseudo = storageService.getPseudo() ?? 'Joueur';
      final playerId = storageService.getPlayerId() ?? const Uuid().v4();

      // Mise à jour de l'état local
      _isHost = false;
      _roomCode = roomCode;

      final success = await _wifiService!.joinRoom(
        hostIp,
        port,
        roomCode,
        Player(
          id: playerId,
          pseudo: pseudo,
          ddkBalance: storageService.getDdkBalance(),
        ),
      );

      if (success) {
        _wifiService!.init(Player(
          id: playerId,
          pseudo: pseudo,
          ddkBalance: storageService.getDdkBalance(),
        ));

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Connecté à la salle !')),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Impossible de rejoindre la salle. Vérifiez l\'IP et le code.')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _showJoinDialog() async {
    // Reset controllers
    _roomCodeController.clear();
    _ipController.clear();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          return Container(
            height: MediaQuery.of(context).size.height * 0.7,
            decoration: const BoxDecoration(
              color: AppTheme.backgroundDark,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: Column(
              children: [
                // Handle
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white30,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                // Title
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      const Icon(Icons.wifi, color: AppTheme.primaryGold, size: 28),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Rejoindre une partie',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white70),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ),
                const Divider(color: Colors.white12),
                // Options
                Expanded(
                  child: DefaultTabController(
                    length: 2,
                    child: Column(
                      children: [
                        const TabBar(
                          indicatorColor: AppTheme.primaryGold,
                          labelColor: AppTheme.primaryGold,
                          unselectedLabelColor: Colors.white60,
                          tabs: [
                            Tab(text: 'Scanner QR Code', icon: Icon(Icons.qr_code_scanner)),
                            Tab(text: 'Entrer IP manuellement', icon: Icon(Icons.keyboard)),
                          ],
                        ),
                        Expanded(
                          child: TabBarView(
                            children: [
                              // QR Scanner Tab
                              _buildQrScannerTab(setModalState),
                              // Manual IP Tab
                              _buildManualIpTab(setModalState),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildQrScannerTab(StateSetter setModalState) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: MobileScanner(
                onDetect: (capture) {
                  final barcodes = capture.barcodes;
                  for (final barcode in barcodes) {
                    final value = barcode.rawValue;
                    if (value != null && value.startsWith('IBZUNG:')) {
                      final data = WiFiService.parseQrData(value);
                      if (data != null) {
                        Navigator.pop(context);
                        _joinRoomWithData(
                          data['hostIp'] as String,
                          data['port'] as int,
                          data['roomCode'] as String,
                        );
                      } else {
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('QR Code Ibizungu invalide')),
                          );
                        }
                      }
                      break;
                    }
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primaryGold.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
            ),
            child: const Row(
              children: [
                Icon(Icons.info_outline, color: AppTheme.primaryGold, size: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Scannez le QR Code affiché par l\'hôte sur son écran',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildManualIpTab(StateSetter setModalState) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // IP Address Field
          TextField(
            controller: _ipController,
            decoration: InputDecoration(
              labelText: 'Adresse IP de l\'hôte',
              hintText: 'Ex: 192.168.1.100',
              prefixIcon: const Icon(Icons.computer),
              filled: true,
              fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: AppTheme.primaryGold, width: 2),
              ),
            ),
            keyboardType: const TextInputType.numberOptions(decimal: true),
          ),
          const SizedBox(height: 16),
          // Room Code Field
          TextField(
            controller: _roomCodeController,
            decoration: InputDecoration(
              labelText: 'Code de la salle',
              hintText: 'Ex: 123456',
              prefixIcon: const Icon(Icons.tag),
              filled: true,
              fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: AppTheme.primaryGold, width: 2),
              ),
            ),
            keyboardType: TextInputType.number,
            maxLength: 6,
            style: const TextStyle(fontSize: 20, letterSpacing: 4),
          ),
          const SizedBox(height: 8),
          // Instructions
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primaryGold.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info_outline, color: AppTheme.primaryGold, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'Comment obtenir l\'IP ?',
                      style: TextStyle(
                        color: AppTheme.primaryGold,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8),
                Text(
                  'L\'hôte peut voir son adresse IP sur son écran (ex: 192.168.1.xx)',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          // Join Button
          ElevatedButton.icon(
            icon: _isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                  )
                : const Icon(Icons.login),
            label: const Text('Rejoindre la partie'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGold,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _isLoading
                ? null
                : () {
                    final ip = _ipController.text.trim();
                    final code = _roomCodeController.text.trim();

                    if (ip.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Veuillez entrer l\'adresse IP')),
                      );
                      return;
                    }

                    if (code.isEmpty || code.length != 6) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Code de salle invalide (6 chiffres requis)')),
                      );
                      return;
                    }

                    Navigator.pop(context);
                    _joinRoomWithData(ip, 8080, code);
                  },
          ),
        ],
      ),
    );
  }

  void _startGame() {
    if (_gameService == null || _wifiService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur: Services non initialisés')),
      );
      return;
    }

    if (_players.length < 3) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Il faut au moins 3 joueurs')),
      );
      return;
    }

    final validPlayerCounts = [3, 4, 6];
    if (!validPlayerCounts.contains(_players.length)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nombre de joueurs invalide (3, 4 ou 6 requis)')),
      );
      return;
    }

    if (_gameMode == GameMode.groups && _players.length != 4 && _players.length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mode Groupes: uniquement 4 ou 6 joueurs requis')),
      );
      return;
    }

    if (_gameMode == GameMode.groups) {
      _gameService!.formTeams();
    }

    final storageService = context.read<StorageService>();
    final currentBet = _betAmount.round();

    for (var player in _players) {
      final newBalance = player.ddkBalance - currentBet;
      if (newBalance < 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${player.pseudo} n\'a pas assez de DDK (solde: ${player.ddkBalance} DDK, mise requise: $currentBet DDK)')),
        );
        return;
      }
      storageService.saveDdkBalance(
        player.id == storageService.getPlayerId() ? newBalance : player.ddkBalance,
      );
    }

    _gameService!.placeBet(currentBet);
    _gameService!.dealCards();

    Navigator.of(context).pushReplacementNamed('/game');
  }

  void _copyRoomCode() {
    if (_roomCode != null) {
      Clipboard.setData(ClipboardData(text: _roomCode!));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Code copié !')),
      );
    }
  }

  void _copyIpAddress() {
    if (_localIp != null) {
      Clipboard.setData(ClipboardData(text: _localIp!));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Adresse IP copiée !')),
      );
    }
  }

  Widget _buildQuickBetButton(int amount) {
    final isSelected = _betAmount.round() == amount;
    return InkWell(
      onTap: () {
        setState(() {
          _betAmount = amount.toDouble();
        });
      },
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryGold
              : AppTheme.primaryGold.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: AppTheme.primaryGold,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Text(
          '$amount',
          style: TextStyle(
            fontSize: 12,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.black : AppTheme.primaryGold,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isHost ? 'Créer une salle' : 'Rejoindre une salle'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            _wifiService?.leaveRoom();
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.pokerGreen,
            ],
          ),
        ),
        child: _isHost ? _buildHostView() : _buildJoinView(),
      ),
    );
  }

  Widget _buildHostView() {
    if (_roomCode == null) {
      return _buildSetupView();
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          // QR Code Card with IP and Room Code
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.wifi, color: AppTheme.primaryGold, size: 24),
                      SizedBox(width: 8),
                      Text(
                        'Connexion Wi-Fi Local',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // IP Address Display
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryGold.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.computer, color: AppTheme.primaryGold, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          _localIp ?? 'Chargement...',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryGold,
                            fontFamily: 'monospace',
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: const Icon(Icons.copy, size: 18, color: AppTheme.primaryGold),
                          onPressed: _copyIpAddress,
                          tooltip: 'Copier l\'IP',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // QR Code with full connection data
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: FutureBuilder<String>(
                      future: _wifiService.generateHostQrData(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          return Column(
                            children: [
                              QrImageView(
                                data: snapshot.data!,
                                version: QrVersions.auto,
                                size: 180,
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'QR Code de connexion',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black54,
                                ),
                              ),
                            ],
                          );
                        }
                        return const SizedBox(
                          width: 180,
                          height: 180,
                          child: Center(child: CircularProgressIndicator()),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Room Code
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'Code: ',
                        style: TextStyle(fontSize: 16),
                      ),
                      Text(
                        _roomCode!,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 4,
                          color: AppTheme.primaryGold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.copy, size: 20),
                        onPressed: _copyRoomCode,
                        tooltip: 'Copier le code',
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.blue.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.info_outline, color: Colors.lightBlueAccent, size: 16),
                        SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            'Les autres joueurs peuvent scanner ce QR Code ou entrer manuellement',
                            style: TextStyle(color: Colors.lightBlueAccent, fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Players
          const Text(
            'Joueurs',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            alignment: WrapAlignment.center,
            children: _players.map((player) {
              return PlayerAvatar(
                player: player,
                size: 80,
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Text(
            '${_players.length} / $_playerCount joueurs',
            style: const TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 16),

          // Bet Display
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(
              color: AppTheme.primaryGold.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.primaryGold.withValues(alpha: 0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.monetization_on,
                  color: AppTheme.primaryGold,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Text(
                  'Mise: ${_betAmount.round()} DDK / joueur',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primaryGold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Start Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _players.length >= 3 ? _startGame : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryGold,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Démarrer la partie',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSetupView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 40),
          const Center(
            child: Icon(
              Icons.wifi,
              size: 80,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Multijoueur Local',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Créez une salle et invitez vos amis via Wi-Fi local',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 40),

          // Game Mode
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Mode de jeu',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  RadioListTile<GameMode>(
                    title: const Text('Mode Individuel'),
                    subtitle: const Text('Chaque joueur joue seul'),
                    value: GameMode.individual,
                    groupValue: _gameMode,
                    onChanged: (value) {
                      setState(() => _gameMode = value!);
                    },
                  ),
                  RadioListTile<GameMode>(
                    title: const Text('Mode Groupes'),
                    subtitle: const Text('Équipes de 2-3 joueurs'),
                    value: GameMode.groups,
                    groupValue: _gameMode,
                    onChanged: (value) {
                      setState(() => _gameMode = value!);
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Player Count
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Nombre de joueurs',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    children: [4, 6].map((count) {
                      return ChoiceChip(
                        label: Text('$count'),
                        selected: _playerCount == count,
                        onSelected: (selected) {
                          if (selected) {
                            setState(() => _playerCount = count);
                          }
                        },
                      );
                    }).toList(),
                  ),
                  if (_gameMode == GameMode.individual) ...[
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 12,
                      children: [
                        ChoiceChip(
                          label: const Text('3'),
                          selected: _playerCount == 3,
                          onSelected: (selected) {
                            if (selected) {
                              setState(() => _playerCount = 3);
                            }
                          },
                        ),
                      ],
                    ),
                  ],
                  if (_gameMode == GameMode.groups) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryGold.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.white54, size: 16),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Mode Groupes: uniquement 4 ou 6 joueurs',
                              style: TextStyle(color: Colors.white54, fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Bet Amount
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Mise de départ',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryGold.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppTheme.primaryGold),
                        ),
                        child: Text(
                          '${_betAmount.round()} DDK',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primaryGold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Chaque joueur doit avoir ce montant pour participer',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text(
                        '50',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                      Expanded(
                        child: Slider(
                          value: _betAmount,
                          min: _minBet,
                          max: _maxBet,
                          divisions: 49,
                          activeColor: AppTheme.primaryGold,
                          inactiveColor: AppTheme.primaryGold.withValues(alpha: 0.3),
                          onChanged: (value) {
                            setState(() {
                              _betAmount = value;
                            });
                          },
                        ),
                      ),
                      const Text(
                        '500',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildQuickBetButton(50),
                      _buildQuickBetButton(100),
                      _buildQuickBetButton(200),
                      _buildQuickBetButton(300),
                      _buildQuickBetButton(500),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 40),

          // Create Button
          ElevatedButton.icon(
            icon: _isLoading
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.add),
            label: const Text('Créer une salle'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGold,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _isLoading ? null : _createRoom,
          ),
        ],
      ),
    );
  }

  Widget _buildJoinView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 40),
          const Center(
            child: Icon(
              Icons.login,
              size: 80,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Rejoindre une partie',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppTheme.primaryGold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Connectez-vous à un ami via Wi-Fi local',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 40),

          // QR Scanner Button
          Card(
            child: InkWell(
              onTap: _showJoinDialog,
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryGold.withValues(alpha: 0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.qr_code_scanner,
                        size: 48,
                        color: AppTheme.primaryGold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Scanner QR Code',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Ou entrer l\'IP manuellement',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Manual Entry Button
          OutlinedButton.icon(
            icon: const Icon(Icons.keyboard),
            label: const Text('Entrer IP manuellement'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.primaryGold,
              side: const BorderSide(color: AppTheme.primaryGold),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _showJoinDialog,
          ),
          const SizedBox(height: 40),

          // Instructions
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.info_outline, color: AppTheme.primaryGold),
                      SizedBox(width: 8),
                      Text(
                        'Instructions',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    '1. Demandez à l\'hôte de vous montrer son QR Code\n'
                    '2. Vérifiez que vous êtes connecté au même Wi-Fi\n'
                    '3. Scannez le QR Code ou entrez l\'IP manuellement',
                    style: TextStyle(height: 1.5),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.amber.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.warning_amber, color: Colors.amber, size: 16),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Les deux appareils doivent être sur le même réseau Wi-Fi',
                            style: TextStyle(color: Colors.amber, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
