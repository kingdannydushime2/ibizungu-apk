import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/services.dart';
import '../utils/theme.dart';
import '../widgets/widgets.dart';

/// Écran principal du jeu
class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  PlayingCard? _selectedCard;
  GameService? _gameService;
  WiFiService? _wifiService;
  final List<String> _disconnectedPlayers = [];

  @override
  void initState() {
    super.initState();
    // Utilise le Provider pour obtenir les services partagés
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _gameService = context.read<GameService>();
      _wifiService = context.read<WiFiService>();

      // Configure le callback de broadcast pour le GameService (hôte uniquement)
      _gameService!.setBroadcastCallback((state) {
        if (_wifiService?.isHost == true) {
          _wifiService?.broadcastGameState(state);
        }
      });

      // Écoute les changements d'état locaux (pour l'hôte)
      _gameService!.addStateListener(_onGameStateChanged);

      // Écoute les états de jeu distants (pour les clients)
      _wifiService!.addGameStateListener(_onRemoteGameState);

      _checkGameEnd();
    });
  }

  @override
  void dispose() {
    _gameService?.removeStateListener(_onGameStateChanged);
    _wifiService?.removeGameStateListener(_onRemoteGameState);
    _gameService?.setBroadcastCallback(null);
    super.dispose();
  }

  /// Gère les mises à jour d'état distantes (reçues via WiFi)
  void _onRemoteGameState(GameState remoteState) {
    // Met à jour le GameService local avec l'état reçu
    // Cela met à jour l'état SANS re-broadcast (évite les boucles infinies)
    _gameService?.updateFromRemote(remoteState);
  }

  void _onGameStateChanged(GameState state) {
    setState(() {});
    _checkGameEnd();
  }

  void _checkGameEnd() {
    if (_gameService == null) return;
    final state = _gameService!.gameState;
    if (state != null && state.status == GameStatus.finished && state.winnerId != null) {
      // Navigation vers l'écran de fin
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pushReplacementNamed(
          '/game-end',
          arguments: {
            'winnerId': state.winnerId,
            'message': state.message ?? 'Partie terminée',
            'mode': state.mode,
            'potAmount': state.potAmount,
          },
        );
      });
    }
  }

  void _playCard(PlayingCard card) {
    if (_selectedCard == null) {
      setState(() => _selectedCard = card);
    } else if (_selectedCard == card) {
      // Joue la carte sélectionnée
      final storageService = context.read<StorageService>();
      final playerId = storageService.getPlayerId();

      if (playerId != null && _gameService != null && _wifiService != null) {
        if (_wifiService!.isHost) {
          // Hôte: joue directement sur le GameService local
          _gameService!.playCard(playerId, card);
        } else {
          // Client: envoie l'action via WiFiService
          _wifiService!.sendGameAction('play_card', {
            'card': card.toJson(),
          });
        }
        setState(() => _selectedCard = null);
      }
    }
  }

  void _confirmPlayCard() {
    if (_selectedCard != null) {
      final storageService = context.read<StorageService>();
      final playerId = storageService.getPlayerId();

      if (playerId != null && _gameService != null && _wifiService != null) {
        if (_wifiService!.isHost) {
          // Hôte: joue directement sur le GameService local
          _gameService!.playCard(playerId, _selectedCard!);
        } else {
          // Client: envoie l'action via WiFiService
          _wifiService!.sendGameAction('play_card', {
            'card': _selectedCard!.toJson(),
          });
        }
        setState(() => _selectedCard = null);
      }
    }
  }

  void _showQuitDialog() {
    final state = _gameService!.gameState;
    final isGroupsMode = state?.mode == GameMode.groups;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Quitter la partie ?'),
        content: Text(
          isGroupsMode
              ? 'Êtes-vous sûr de vouloir quitter ? En Mode Groupes, vous perdrez votre mise et la partie sera fermée.'
              : 'Êtes-vous sûr de vouloir quitter la partie ? Vous perdrez votre mise.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.of(this.context).pushReplacementNamed('/home');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.error,
            ),
            child: const Text('Quitter'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Récupère le GameService du Provider
    final gameService = context.watch<GameService>();
    final state = gameService.gameState;
    final storageService = context.watch<StorageService>();
    final playerId = storageService.getPlayerId();

    if (_gameService == null) {
      _gameService = context.read<GameService>();
    }

    if (state == null) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final myCards = state.playerCards[playerId] ?? [];
    final currentPlayer = state.currentPlayer;
    final isMyTurn = currentPlayer?.id == playerId;

    return Scaffold(
      appBar: AppBar(
        title: Text('Salle ${state.roomCode}'),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: _showQuitDialog,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                'Pot: ${state.potAmount} DDK',
                style: const TextStyle(
                  color: AppTheme.primaryGold,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.pokerGreen,
              AppTheme.feltGreen,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Indicateur de mode et équipes
              _buildModeIndicator(state),

              // Message d'état
              if (state.message != null)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryGold.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: AppTheme.primaryGold.withValues(alpha: 0.5),
                    ),
                  ),
                  child: Text(
                    state.message!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.primaryGold,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

              // Couleur forte
              if (state.strongSuit != null)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.star, color: AppTheme.primaryGold, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        'Couleur forte (iyatotse): ${state.strongSuit!.symbol}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 16),

              // Joueurs en haut avec équipes
              _buildPlayersSection(state),

              const SizedBox(height: 16),

              // Table de jeu (cartes sur la table)
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.pokerGreenLight.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: AppTheme.primaryGold.withValues(alpha: 0.3),
                      width: 2,
                    ),
                  ),
                  child: Center(
                    child: state.tableCards.isEmpty
                        ? const Text(
                            'Cartes jouées',
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 16,
                            ),
                          )
                        : Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            alignment: WrapAlignment.center,
                            children: state.tableCards.map((card) {
                              return CardWidget(
                                card: card,
                                size: 60,
                              );
                            }).toList(),
                          ),
                  ),
                ),
              ),

              // Pli en cours
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'Pli ${state.trickNumber}',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // Cartes du joueur
              Container(
                height: 140,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: myCards.length,
                  itemBuilder: (context, index) {
                    final card = myCards[index];
                    final isSelected = _selectedCard == card;

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: GestureDetector(
                        onTap: isMyTurn ? () => _playCard(card) : null,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          transform: isSelected
                              ? (Matrix4.identity()..translate(0.0, -20.0))
                              : Matrix4.identity(),
                          child: CardWidget(
                            card: card,
                            isSelected: isSelected,
                            size: 70,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              // Bouton jouer
              if (_selectedCard != null && isMyTurn)
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.check),
                      label: Text('Jouer ${_selectedCard!.fullName}'),
                      onPressed: _confirmPlayCard,
                    ),
                  ),
                ),

              // Indicateur de tour
              if (!isMyTurn)
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    'Tour de ${currentPlayer?.pseudo ?? '...'}',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModeIndicator(GameState state) {
    final isGroups = state.mode == GameMode.groups;
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isGroups 
            ? Colors.blue.withValues(alpha: 0.2)
            : AppTheme.primaryGold.withValues(alpha: 0.2),
        border: Border(
          bottom: BorderSide(
            color: isGroups ? Colors.blue : AppTheme.primaryGold,
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            isGroups ? Icons.groups : Icons.person,
            size: 16,
            color: isGroups ? Colors.blue : AppTheme.primaryGold,
          ),
          const SizedBox(width: 8),
          Text(
            isGroups ? 'MODE GROUPES' : 'MODE INDIVIDUEL',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: isGroups ? Colors.blue : AppTheme.primaryGold,
            ),
          ),
          if (isGroups) ...[
            const SizedBox(width: 16),
            const Text(
              '|',
              style: TextStyle(color: Colors.white38),
            ),
            const SizedBox(width: 16),
            const Icon(
              Icons.shield,
              size: 16,
              color: Colors.blue,
            ),
            const SizedBox(width: 8),
            Text(
              _getTeamInfo(state),
              style: const TextStyle(
                fontSize: 12,
                color: Colors.blue,
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _getTeamInfo(GameState state) {
    final storageService = context.read<StorageService>();
    final playerId = storageService.getPlayerId();
    
    for (var player in state.players) {
      if (player.id == playerId && player.teamId != null) {
        return 'Équipe: ${player.teamId}';
      }
    }
    return '';
  }

  Widget _buildPlayersSection(GameState state) {
    final isGroups = state.mode == GameMode.groups;
    
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: state.players.length,
        itemBuilder: (context, index) {
          final player = state.players[index];
          final isCurrentTurn = index == state.currentPlayerIndex;
          final isDisconnected = !player.isConnected;
          
          // Récupère le StorageService ici pour éviter l'erreur
          final storageService = context.read<StorageService>();
          final isMe = player.id == storageService.getPlayerId();
          
          return Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Column(
              children: [
                Stack(
                  children: [
                    PlayerAvatar(
                      player: player,
                      isCurrentTurn: isCurrentTurn,
                      isAdminView: false,
                      teamColor: isGroups ? _getTeamColor(player.teamId, state) : null,
                    ),
                    // Indicateur "Moi"
                    if (isMe)
                      Positioned(
                        top: 0,
                        left: 0,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryGold,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'Moi',
                            style: TextStyle(
                              fontSize: 8,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    // Indicateur d'équipe
                    if (isGroups && player.teamId != null)
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          height: 3,
                          decoration: BoxDecoration(
                            color: _getTeamColor(player.teamId, state),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                // Affiche le pseudo avec indication de déconnexion
                Text(
                  isDisconnected ? '${player.pseudo} (quitté)' : player.pseudo,
                  style: TextStyle(
                    color: isDisconnected ? Colors.red : Colors.white,
                    fontSize: 10,
                    fontStyle: isDisconnected ? FontStyle.italic : FontStyle.normal,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Color _getTeamColor(String? teamId, GameState state) {
    if (teamId == null) return Colors.transparent;
    
    final teamIndex = int.tryParse(teamId.replaceAll('team_', '')) ?? 0;
    return teamIndex.isEven ? Colors.red : Colors.blue;
  }
}
