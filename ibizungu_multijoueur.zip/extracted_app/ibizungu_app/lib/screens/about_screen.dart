import 'package:flutter/material.dart';
import '../utils/theme.dart';

/// Écran À propos
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('À propos'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              // Logo
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.primaryGold,
                      AppTheme.primaryGold.withValues(alpha: 0.7),
                    ],
                  ),
                ),
                child: const Center(
                  child: Text(
                    'IBZ',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Ibizungu',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryGold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Version 1.0.0',
                style: TextStyle(color: Colors.white54),
              ),
              const SizedBox(height: 32),
              // Citation
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: AppTheme.primaryGold.withValues(alpha: 0.3),
                  ),
                ),
                child: const Text(
                  '"Uyu mukino wakozwe na Danny kugira ngo mushobore kuryoherwa no gutsindira amahera mukuryoherwa"',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    fontStyle: FontStyle.italic,
                    color: Colors.white70,
                    height: 1.5,
                  ),
                ),
              ),
              const SizedBox(height: 32),
              // Description
              const Text(
                'Règles du jeu',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              _buildRuleSection(
                'Mode Individuel',
                'Chaque joueur joue seul. Le joueur avec le plus d\'ibimari (As et 7) ou le plus de points gagne.',
              ),
              _buildRuleSection(
                'Mode Groupes',
                'Les joueurs sont répartis en équipes de 2-3. L\'équipe avec le plus d\'ibimari ou de points gagne.',
              ),
              _buildRuleSection(
                'Cartes',
                '24 cartes au total : As, 7, Roi, Valet, Dame, 6 pour chaque couleur (♥ ♦ ♣ ♠).',
              ),
              _buildRuleSection(
                'Hiérarchie',
                'As > 7 > Roi > Valet > Dame > 6. La couleur forte (iyatotse) est déterminée par la première carte jouée.',
              ),
              _buildRuleSection(
                'Points',
                'K=4pts, J=3pts, Q=2pts, 6=0pt. As et 7 sont des ibimari (victoire automatique à 5).',
              ),
              const SizedBox(height: 32),
              // Développeur
              const Text(
                'Développé avec ❤️ par Danny',
                style: TextStyle(color: Colors.white54),
              ),
              const SizedBox(height: 8),
              const Text(
                '© 2024 Ibizungu',
                style: TextStyle(color: Colors.white38),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRuleSection(String title, String content) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryGold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              content,
              style: const TextStyle(
                color: Colors.white70,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
