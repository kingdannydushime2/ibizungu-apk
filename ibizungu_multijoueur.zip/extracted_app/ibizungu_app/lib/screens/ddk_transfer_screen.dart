import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../services/services.dart';
import '../utils/theme.dart';
import '../utils/helpers.dart';

/// Écran de transfert DDK via QR Code
class DdkTransferScreen extends StatefulWidget {
  const DdkTransferScreen({super.key});

  @override
  State<DdkTransferScreen> createState() => _DdkTransferScreenState();
}

class _DdkTransferScreenState extends State<DdkTransferScreen> {
  bool _isLoading = false;
  String? _transferCode;

  static const int transferAmount = 50;

  void _generateTransferCode() {
    final storageService = context.read<StorageService>();
    final currentBalance = storageService.getDdkBalance();

    if (currentBalance < transferAmount) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Solde insuffisant'),
          backgroundColor: AppTheme.error,
        ),
      );
      return;
    }

    final playerId = storageService.getPlayerId() ?? '';
    final pseudo = storageService.getPseudo() ?? '';
    final code = Helpers.generateDDKTransferCode(
      playerId,
      '', // Le destinataire sera défini lors du scan
      transferAmount,
      senderPseudo: pseudo,
    );

    setState(() {
      _transferCode = code;
    });
  }

  Future<void> _confirmTransfer() async {
    if (_transferCode == null) return;

    setState(() => _isLoading = true);

    try {
      final storageService = context.read<StorageService>();
      final currentBalance = storageService.getDdkBalance();

      // Déduit les DDK
      await storageService.saveDdkBalance(currentBalance - transferAmount);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('50 DDK envoyés avec succès !'),
            backgroundColor: AppTheme.success,
          ),
        );

        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final balance = storageService.getDdkBalance();
    final canTransfer = balance >= transferAmount;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Envoyer des DDK'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Solde actuel
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.account_balance_wallet),
                      const SizedBox(width: 12),
                      Text(
                        'Solde: ${Helpers.formatDDK(balance)}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              // Instructions
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceDark,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Column(
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: AppTheme.primaryGold,
                      size: 32,
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Envoie 50 DDK à un autre joueur',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Un QR Code sera généré. Demande à l\'autre joueur de scanner ce QR Code.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              // QR Code ou bouton générer
              if (_transferCode == null)
                ElevatedButton.icon(
                  icon: const Icon(Icons.qr_code),
                  label: const Text('Générer QR Code'),
                  onPressed: canTransfer && !_isLoading ? _generateTransferCode : null,
                )
              else
                Column(
                  children: [
                    // QR Code
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          QrImageView(
                            data: _transferCode!,
                            version: QrVersions.auto,
                            size: 200,
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'Scannez ce QR Code',
                            style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Valide pendant 2 minutes',
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Montant
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryGold.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppTheme.primaryGold.withValues(alpha: 0.3),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.send, color: AppTheme.primaryGold),
                          const SizedBox(width: 8),
                          Text(
                            '${transferAmount} DDK',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: AppTheme.primaryGold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    // Bouton confirmer
                    ElevatedButton.icon(
                      icon: _isLoading
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.check),
                      label: const Text('Confirmer l\'envoi'),
                      onPressed: _isLoading ? null : _confirmTransfer,
                    ),
                    const SizedBox(height: 12),
                    TextButton(
                      onPressed: () {
                        setState(() => _transferCode = null);
                      },
                      child: const Text('Annuler'),
                    ),
                  ],
                ),
              if (!canTransfer) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.error.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: AppTheme.error.withValues(alpha: 0.5),
                    ),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.warning, color: AppTheme.error),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Solde insuffisant (minimum $transferAmount DDK)',
                          style: TextStyle(color: AppTheme.error),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
