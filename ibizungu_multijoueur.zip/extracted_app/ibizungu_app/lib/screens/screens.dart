// Export all screens
export 'onboarding_screen.dart';
export 'home_screen.dart';
export 'game_lobby_screen.dart';
export 'game_screen.dart';
export 'history_screen.dart';
export 'about_screen.dart';
export 'ddk_exchange_screen.dart';
export 'ddk_transfer_screen.dart';
export 'buy_ddk_screen.dart';
export 'receive_ddk_screen.dart';
export 'game_end_screen.dart';
// CORRIGÉ: AdminGameView était défini dans main.dart, à déplacer dans un fichier séparé
// Pour l'instant, on garde l'export manquant comme référence
