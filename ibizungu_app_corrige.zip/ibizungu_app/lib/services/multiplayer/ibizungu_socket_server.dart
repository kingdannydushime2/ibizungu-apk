import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'socket_message.dart';
import 'network_discovery_service.dart';

/// Callback pour les événements de la room
typedef RoomEventCallback = void Function(dynamic data);

/// Serveur Socket pour l'hôte du jeu
/// Gère les connexions des clients et la synchronisation de l'état du jeu
class IbizunguSocketServer {
  ServerSocket? _server;
  RawDatagramSocket? _udpServer;
  final List<Socket> _clients = [];
  final Map<String, GameParticipant> _participants = {};
  String? _roomCode;
  int? _port;
  Map<String, dynamic>? _currentGameState; // État actuel du jeu
  String? _hostName;
  bool _discoveryEnabled = false;

  // Callbacks pour les événements
  RoomEventCallback? onParticipantJoined;
  RoomEventCallback? onParticipantLeft;
  RoomEventCallback? onParticipantsUpdated;
  RoomEventCallback? onGameStateRequested;
  RoomEventCallback? onGameAction;
  RoomEventCallback? onDisconnect;

  // Callbacks pour la gestion interne
  final List<Function(dynamic)> _gameStateListeners = [];

  bool get isRunning => _server != null;
  String? get roomCode => _roomCode;
  int? get port => _port;
  List<GameParticipant> get participants => _participants.values.toList();
  int get participantCount => _participants.length;
  Map<String, dynamic>? get currentGameState => _currentGameState;
  bool get isDiscoveryEnabled => _discoveryEnabled;

  /// Démarre le serveur sur le port spécifié
  Future<bool> start({int port = 8080, bool enableDiscovery = true}) async {
    try {
      _server = await ServerSocket.bind(
        InternetAddress.anyIPv4,
        port,
        shared: true,
      );
      _port = port;

      _server!.listen(
        _handleIncomingConnection,
        onError: _handleServerError,
        onDone: _handleServerDone,
      );

      debugPrint('Serveur démarré sur le port $port');

      // Démarre le serveur de découverte UDP si demandé
      if (enableDiscovery) {
        await _startDiscoveryServer();
      }

      return true;
    } catch (e) {
      debugPrint('Erreur démarrage serveur: $e');
      return false;
    }
  }

  /// Démarre le serveur de découverte UDP
  Future<void> _startDiscoveryServer() async {
    try {
      const discoveryPort = 8081;
      _udpServer = await RawDatagramSocket.bind(
        InternetAddress.anyIPv4,
        discoveryPort,
        reuseAddress: true,
        reusePort: true,
      );

      _udpServer!.broadcastEnabled = true;

      _udpServer!.listen((event) {
        if (event == RawSocketEvent.read) {
          final datagram = _udpServer!.receive();
          if (datagram != null) {
            _handleDiscoveryRequest(datagram);
          }
        }
      });

      _discoveryEnabled = true;
      debugPrint('Serveur de découverte UDP démarré sur le port $discoveryPort');
    } catch (e) {
      debugPrint('Erreur démarrage serveur découverte: $e');
    }
  }

  /// Gère les requêtes de découverte
  void _handleDiscoveryRequest(Datagram datagram) {
    try {
      final data = String.fromCharCodes(datagram.data);
      final parts = data.split(':');

      if (parts.length >= 2 && parts[0] == NetworkDiscoveryService.broadcastIdentifier) {
        if (parts[1] == 'SCAN_REQUEST') {
          // Répond avec les informations de la salle
          final localIp = _getLocalIpAddress();
          final response = 'IBZUNG_DISCOVER:SCAN_RESPONSE:$localIp:$_port:$_roomCode:$_hostName';
          final responseData = response.codeUnits;

          _udpServer!.send(
            responseData,
            datagram.address,
            NetworkDiscoveryService.broadcastPort,
          );

          debugPrint('Réponse de découverte envoyée à ${datagram.address}');
        }
      }
    } catch (e) {
      debugPrint('Erreur traitement découverte: $e');
    }
  }

  /// Obtient l'adresse IP locale
  String _getLocalIpAddress() {
    try {
      final interfaces = NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
      );

      for (var interface in interfaces) {
        for (var addr in interface.addresses) {
          if (!addr.isLoopback) {
            return addr.address;
          }
        }
      }
    } catch (e) {
      debugPrint('Erreur obtention IP: $e');
    }
    return '127.0.0.1';
  }

  /// Définit le nom de l'hôte pour la découverte
  void setHostName(String name) {
    _hostName = name;
  }

  /// Arrête le serveur
  Future<void> stop() async {
    // Notifie tous les clients que la room est fermée
    _broadcastToAll({
      'type': 'room_closed',
      'path': '/room/closed',
      'data': RoomClosedMessage(
        roomCode: _roomCode ?? '',
        reason: 'L\'hôte a fermé la salle',
      ).toJson(),
    });

    // Ferme toutes les connexions clients
    for (var client in _clients) {
      try {
        await client.close();
      } catch (e) {
        debugPrint('Erreur fermeture client: $e');
      }
    }
    _clients.clear();
    _participants.clear();

    // Ferme le serveur UDP de découverte
    _udpServer?.close();
    _udpServer = null;
    _discoveryEnabled = false;

    // Ferme le serveur TCP
    await _server?.close();
    _server = null;
    _roomCode = null;
    _port = null;

    debugPrint('Serveur arrêté');
  }

  /// Configure la room
  void setRoom(String roomCode, List<GameParticipant> initialParticipants) {
    _roomCode = roomCode;
    _participants.clear();
    for (var participant in initialParticipants) {
      _participants[participant.id] = participant;
    }
  }

  /// Met à jour l'état actuel du jeu (pour l'envoyer aux clients qui rejoignent)
  void setGameState(Map<String, dynamic>? gameState) {
    _currentGameState = gameState;
  }

  /// Ajoute un participant
  void addParticipant(GameParticipant participant) {
    _participants[participant.id] = participant;
  }

  /// Retire un participant
  void removeParticipant(String participantId) {
    _participants.remove(participantId);
  }

  /// Met à jour un participant
  void updateParticipant(GameParticipant participant) {
    _participants[participant.id] = participant;
  }

  /// Gère les connexions entrantes
  void _handleIncomingConnection(Socket client) {
    debugPrint('Nouvelle connexion entrante');
    _clients.add(client);
    _handleClientSocket(client);
  }

  /// Gère les messages d'un client
  void _handleClientSocket(Socket client) {
    String? currentRoomCode;
    String? currentParticipantId;

    client.listen(
      (data) {
        try {
          final messageString = utf8.decode(data);
          final message = SocketMessage.decode(messageString);

          if (message == null) {
            debugPrint('Message invalide reçu');
            return;
          }

          debugPrint('Message reçu: ${message.type} - ${message.path}');

          switch (message.type) {
            case 'join':
              _handleJoin(client, message, (participant, participants) {
                currentParticipantId = participant.id;
                currentRoomCode = participant.isHost ? message.data?['roomCode'] : currentRoomCode;
                onParticipantJoined?.call(participant);
                onParticipantsUpdated?.call(participants);
              });
              break;

            case 'leave':
              _handleLeave(client, message, (participantId) {
                if (currentParticipantId != null) {
                  onParticipantLeft?.call(participantId);
                }
              });
              break;

            case 'request_state':
              _handleRequestState(client, message);
              break;

            case 'game_action':
              _handleGameAction(client, message);
              break;

            case 'disconnect':
              _handleDisconnect(client, message);
              break;

            default:
              debugPrint('Type de message inconnu: ${message.type}');
          }
        } catch (e) {
          debugPrint('Erreur traitement message: $e');
        }
      },
      onError: (error) {
        debugPrint('Erreur socket client: $error');
        _handleClientError(client, currentParticipantId);
      },
      onDone: () {
        debugPrint('Client déconnecté');
        _handleClientDone(client, currentParticipantId);
      },
    );
  }

  /// Gère la connexion d'un client
  void _handleJoin(Socket client, SocketMessage message, Function(GameParticipant, List<GameParticipant>) onSuccess) {
    try {
      final data = message.data;
      if (data == null) return;

      final participant = GameParticipant.fromJson(data['participant'] as Map<String, dynamic>);
      final roomCode = data['roomCode'] as String?;

      // Vérifie que le code de room correspond
      if (_roomCode != null && roomCode != null && _roomCode != roomCode) {
        _sendToClient(client, {
          'type': 'error',
          'path': '/join/error',
          'data': {'error': 'Code de salle invalide'},
        });
        return;
      }

      // Ajoute le participant
      _participants[participant.id] = participant;

      // Configure l'identifiant du participant pour ce client
      // Répond avec accusé de réception INCLUANT l'état du jeu actuel
      _sendToClient(client, {
        'type': 'join_ack',
        'path': '/join/ack',
        'data': ConnectionAckMessage(
          success: true,
          participant: participant,
          existingParticipants: _participants.values.toList(),
          roomCode: _roomCode,
          gameState: _currentGameState,
        ).toJson(),
      });

      // Notifie les autres participants
      _broadcastToOthers(client, {
        'type': 'participant_joined',
        'path': '/room/participant_joined',
        'data': {
          'participant': participant.toJson(),
          'participants': _participants.values.map((p) => p.toJson()).toList(),
        },
      });

      onSuccess(participant, _participants.values.toList());

    } catch (e) {
      debugPrint('Erreur join: $e');
      _sendToClient(client, {
        'type': 'error',
        'path': '/join/error',
        'data': {'error': 'Erreur lors de la connexion'},
      });
    }
  }

  /// Gère la déconnexion d'un client
  void _handleLeave(Socket client, SocketMessage message, Function(String) onLeave) {
    try {
      final data = message.data;
      if (data == null) return;

      final participantId = data['participantId'] as String?;

      if (participantId != null) {
        _participants.remove(participantId);

        // Notifie les autres participants
        _broadcastToOthers(client, {
          'type': 'participant_left',
          'path': '/room/participant_left',
          'data': {
            'participantId': participantId,
            'participants': _participants.values.map((p) => p.toJson()).toList(),
          },
        });

        onLeave(participantId);
      }
    } catch (e) {
      debugPrint('Erreur leave: $e');
    }
  }

  /// Gère la demande d'état du jeu
  void _handleRequestState(Socket client, SocketMessage message) {
    onGameStateRequested?.call(client);
  }

  /// Gère les actions de jeu
  void _handleGameAction(Socket client, SocketMessage message) {
    onGameAction?.call(message.data);
  }

  /// Gère la déconnexion
  void _handleDisconnect(Socket client, SocketMessage message) {
    _handleClientDone(client, message.data?['participantId']);
  }

  /// Gère les erreurs du serveur
  void _handleServerError(Object error) {
    debugPrint('Erreur serveur: $error');
  }

  /// Gère la fermeture du serveur
  void _handleServerDone() {
    debugPrint('Serveur fermé');
  }

  /// Gère les erreurs d'un client
  void _handleClientError(Socket client, String? participantId) {
    debugPrint('Erreur client: $participantId');
    _clients.remove(client);
    if (participantId != null) {
      _participants.remove(participantId);
      _broadcastToAll({
        'type': 'participant_left',
        'path': '/room/participant_left',
        'data': {
          'participantId': participantId,
          'participants': _participants.values.map((p) => p.toJson()).toList(),
        },
      });
      onParticipantLeft?.call(participantId);
    }
  }

  /// Gère la déconnexion d'un client
  void _handleClientDone(Socket client, String? participantId) {
    _clients.remove(client);
    if (participantId != null && _participants.containsKey(participantId)) {
      _participants.remove(participantId);
      _broadcastToAll({
        'type': 'participant_left',
        'path': '/room/participant_left',
        'data': {
          'participantId': participantId,
          'participants': _participants.values.map((p) => p.toJson()).toList(),
        },
      });
      onParticipantLeft?.call(participantId);
      onDisconnect?.call(participantId);
    }
  }

  /// Envoie un message à un client spécifique
  void _sendToClient(Socket client, Map<String, dynamic> message) {
    try {
      client.write(jsonEncode(message));
    } catch (e) {
      debugPrint('Erreur envoi message: $e');
    }
  }

  /// Diffuse un message à tous les clients
  void broadcast(Map<String, dynamic> message) {
    _broadcastToAll(message);
  }

  /// Diffuse un message à tous les clients
  void _broadcastToAll(Map<String, dynamic> message) {
    for (var client in _clients) {
      _sendToClient(client, message);
    }
  }

  /// Diffuse un message à tous les clients sauf l'expéditeur
  void _broadcastToOthers(Socket sender, Map<String, dynamic> message) {
    for (var client in _clients) {
      if (client != sender) {
        _sendToClient(client, message);
      }
    }
  }

  /// Diffuse la liste des participants
  void broadcastParticipants() {
    _broadcastToAll({
      'type': 'participants_update',
      'path': '/room/participants',
      'data': {
        'participants': _participants.values.map((p) => p.toJson()).toList(),
      },
    });
  }

  /// Diffuse l'état du jeu à tous les clients
  void broadcastGameState(Map<String, dynamic> gameState) {
    _broadcastToAll({
      'type': 'game_state',
      'path': '/game/state',
      'data': GameStateMessage(gameState: gameState).toJson(),
    });
  }

  /// Diffuse le message de fin de jeu
  void broadcastGameOver(String winnerId, String message, int potAmount, Map<String, dynamic>? finalState) {
    _broadcastToAll({
      'type': 'game_over',
      'path': '/game/over',
      'data': GameOverMessage(
        roomCode: _roomCode ?? '',
        winnerId: winnerId,
        message: message,
        potAmount: potAmount,
        finalState: finalState,
      ).toJson(),
    });
  }

  /// Diffuse le message de démarrage du jeu
  void broadcastGameStart(Map<String, dynamic>? initialGameState) {
    _broadcastToAll({
      'type': 'game_start',
      'path': '/game/start',
      'data': GameStartMessage(
        roomCode: _roomCode ?? '',
        initialGameState: initialGameState,
      ).toJson(),
    });
  }

  /// Diffuse le message de room prête
  void broadcastRoomReady(bool isReady) {
    _broadcastToAll({
      'type': 'room_ready',
      'path': '/room/ready',
      'data': RoomReadyMessage(
        roomCode: _roomCode ?? '',
        isReady: isReady,
      ).toJson(),
    });
  }

  /// Ferme la room
  void closeRoom(String reason) {
    _broadcastToAll({
      'type': 'room_closed',
      'path': '/room/closed',
      'data': RoomClosedMessage(
        roomCode: _roomCode ?? '',
        reason: reason,
      ).toJson(),
    });
  }

  /// Nettoie les ressources
  Future<void> dispose() async {
    await stop();
  }
}
