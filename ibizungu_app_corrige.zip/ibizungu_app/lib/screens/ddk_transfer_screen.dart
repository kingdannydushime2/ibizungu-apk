import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../services/services.dart';
import '../utils/theme.dart';
import '../utils/helpers.dart';

/// Écran de transfert DDK via QR Code
/// Avec thème clair pour une meilleure lisibilité lors de la transaction
class DdkTransferScreen extends StatefulWidget {
  const DdkTransferScreen({super.key});

  @override
  State<DdkTransferScreen> createState() => _DdkTransferScreenState();
}

class _DdkTransferScreenState extends State<DdkTransferScreen> {
  bool _isLoading = false;
  String? _transferCode;

  static const int transferAmount = 50;

  Future<void> _generateTransferCode() async {
    final storageService = context.read<StorageService>();
    final currentBalance = storageService.getDdkBalance();

    if (currentBalance < transferAmount) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Solde insuffisant'),
          backgroundColor: AppTheme.error,
        ),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Déduit les 50 DDK immédiatement à la génération
      await storageService.saveDdkBalance(currentBalance - transferAmount);

      final playerId = storageService.getPlayerId() ?? '';
      final pseudo = storageService.getPseudo() ?? '';
      final code = Helpers.generateDDKTransferCode(
        playerId,
        '', // Le destinataire sera défini lors du scan
        transferAmount,
        senderPseudo: pseudo,
      );

      setState(() {
        _transferCode = code;
        _isLoading = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('50 DDK déduits - QR Code généré!'),
            backgroundColor: AppTheme.success,
          ),
        );
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    }
  }

  void _cancelTransfer() {
    // Remet les DDK si l'utilisateur annule
    final storageService = context.read<StorageService>();
    final currentBalance = storageService.getDdkBalance();
    storageService.saveDdkBalance(currentBalance + transferAmount);

    setState(() => _transferCode = null);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Transfert annulé - 50 DDK rendus'),
        backgroundColor: Colors.orange,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final balance = storageService.getDdkBalance();
    final canTransfer = balance >= transferAmount;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Envoyer des DDK'),
        backgroundColor: AppTheme.backgroundDark,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Solde actuel
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.account_balance_wallet),
                      const SizedBox(width: 12),
                      Text(
                        'Solde: ${Helpers.formatDDK(balance)}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Instructions - THÈME CLAIR
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    const Icon(
                      Icons.swap_horiz,
                      color: AppTheme.primaryDark,
                      size: 32,
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Envoie 50 DDK à un autre joueur',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.primaryDark,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Génère un QR Code que l\'autre joueur scannera pour recevoir les DDK.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.black87),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // QR Code ou bouton générer
              if (_transferCode == null) ...[
                // Avertissement sur la déduction
                Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.amber.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.amber.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: Colors.amber.shade700),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          'Les 50 DDK seront débités dès la génération du QR Code.',
                          style: TextStyle(color: Colors.black87, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
                // Bouton générer
                ElevatedButton.icon(
                  icon: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.qr_code),
                  label: Text(_isLoading ? 'Génération...' : 'Générer QR Code'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryGold,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  onPressed: canTransfer && !_isLoading ? _generateTransferCode : null,
                ),
              ] else ...[
                // QR Code généré - SIMPLE sans confirmation
                _buildQRCodeSection(),
              ],

              if (!canTransfer) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.error.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: AppTheme.error.withValues(alpha: 0.5),
                    ),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.warning, color: AppTheme.error),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Solde insuffisant (minimum $transferAmount DDK)',
                          style: TextStyle(color: AppTheme.error),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQRCodeSection() {
    return Column(
      children: [
        // QR Code - THÈME CLAIR
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.15),
                blurRadius: 15,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            children: [
              QrImageView(
                data: _transferCode!,
                version: QrVersions.auto,
                size: 200,
                backgroundColor: Colors.white,
              ),
              const SizedBox(height: 16),
              const Text(
                'QR Code de transfert',
                style: TextStyle(
                  color: AppTheme.primaryDark,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Valide pendant 2 minutes',
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Montant - THÈME CLAIR
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.green.shade50,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.green.shade200),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.check_circle, color: Colors.green.shade700),
              const SizedBox(width: 8),
              Text(
                '50 DDK débités',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade700,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),

        // Instructions pour le destinataire
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.blue.shade50,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Icon(Icons.person_add, color: Colors.blue.shade700, size: 32),
              const SizedBox(height: 8),
              const Text(
                'Montrez ce QR Code au destinataire',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryDark,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Il devra scanner ce code depuis "Recevoir des DDK"',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.blue.shade700),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // Bouton Annuler
        OutlinedButton.icon(
          icon: const Icon(Icons.close),
          label: const Text('Annuler le transfert'),
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.red.shade400,
            side: BorderSide(color: Colors.red.shade400),
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
          onPressed: _cancelTransfer,
        ),
      ],
    );
  }
}
